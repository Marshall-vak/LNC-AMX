DGX Control Panel Upgrade Information

Current Firmware Version: 2.2.0pre5
Build Date: 11/4/2015 8:50:13 AM
Website Availability: DGX_Control_Panel_Upgrade.zip

This firmware is required to upgrade a DGX 8/16/32/64 
control panel to a DGX 800/1600/3200/6400 control panel 
to take advantage of new features in the DGX 100 Series CPU.

-------------------------------------------------------------
Changes in this release
-------------------------------------------------------------
- Initial release of the DGX 100 Series control panel
  firmware applicable ONLY to DGX 100 Series systems. 

- New feature to present realtime Upgrade Status feedback via
  the LCD.  Also the control panel LED buttons will cycle on
  and off in a chaser pattern during the upgrade.  

- New Setup Options menu item to show additional Master and
  Switcher Information such as IP & MAC address, versions,
  serial number, etc.)  FUNCTION/SETUP OPTIONS/MASTER INFO

- New menu item to allow embedded audio volume adjustment.
  FUNCTION/AUDIO ADJUST

-------------------------------------------------------------
Known Issues 
-------------------------------------------------------------


-------------------------------------------------------------
Programming Information/Instructions
-------------------------------------------------------------
IMPORTANT: See DGX 100 Series Hardware Reference Manual for 
a complete guide on upgrading to a DGX 100 Series system.

NOTE: Update to Control Panel takes approximately 3 minutes.

To Upgrade a DGX Control Panel to a DGX 100 Series Control 
Panel, follow the steps below:

 1. Turn off AC power to the enclosure. Make sure none of the 
    power supply LEDs are illuminated.
 2. Loosen the four captive screws on the control panel.
 3. Carefully pull the control panel straight out from the 
    enclosure. 
 4. Apply power to the enclosure.
 5. Connect a null modem serial cable to the DB9 serial port 
    on the control panel.
 6. Connect the other end of the serial cable to a PC.
 7. Locate and open the DGX_Control_Panel_Upgrade file folder.
 8. Run the Setup.exe program to install AppCodeLoader and 
    any associated files on your PC.
 9. Launch the AppCodeLoader program.
10. Set Serial Port Settings for your system:
 a. Set Baud Rate to 9600
 b. Select the Com port. (Only ports 1-9 are available options.)
11. Browse for the �image-v2.2.0pre5.enc� file to upload.
12. Click the �Start Upload� button and wait for the upload
    to finish.  The [Expected Checksum] and [Returned Checksum]
    will match when the upload is complete. The update takes 
    about 3 minutes and says �Upload Successful!� when complete.
13. Click Exit.
14. Turn off AC power to the enclosure. Make sure none of the 
    power supply LEDs are illuminated.
15. Remove serial cable and replace control panel.  Tighten the
    four captive screws � be careful not to pinch the wires when 
    securing the control panel.
16. Apply power to the enclosure.

If upgrading the rest of the DGX enclosure, follow the steps in 
the DGX Hardware Reference Manual Appendix for Upgrading a system.

Basic Upgrade Steps are:
1. Upgrade Front Panel
2. Install new DGX 100 Series CPU
3. Upgrade enclosure and I/O boards with Kit 3.0.10 (or later)
4. Upgrade endpoints with compatible versions as listed in DGX Kit



