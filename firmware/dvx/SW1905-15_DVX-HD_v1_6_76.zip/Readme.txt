------------------- C A U T I O N --------------------------
If using a DVX3156-SP (-T) configuration, the Switcher must be running v1.6.13 or above 
Switcher firmware. The Master must be running versions 4.8.304 and above to use 
the web configuration page.
------------------------------------------------------------

DVX-31xxHD-SP (-T) and DVX-21xxHD-SP (-T)
Enova Presentation Switcher with power Amp

FG#: FG1905-22 (DVX3156HD-SP)
FG#: FG1905-16 (DVX3155HD-SP)
FG#: FG1905-15 (DVX3150HD-SP)
FG#: FG1905-11 (DVX2150HD-SP)
FG#: FG1905-12 (DVX2155HD-SP)
FG#: FG1905-24 (DVX3156HD-T)
FG#: FG1905-18 (DVX3155HD-T)
FG#: FG1905-17 (DVX3150HD-T)
FG#: FG1905-13 (DVX2150HD-T)
FG#: FG1905-14 (DVX2155HD-T)
FG#: FG1905-07 (DVX2110HD-SP)
FG#: FG1905-09 (DVX2110HD-T)

Current Firmware Version:
Switcher: v1.6.76  SW1905-15_DVX-HD_v1_6_76.kit

Release Date: 1/27/2016

NOTE: To ensure a successful firmware upgrade with this release please refer
      to the file "SW1905-15-DVX-HD-SP-ProgrammingInstructions.txt".

Prerequisites:
   NI Device  5001: 1.31.6
   Master         : 4.8.304


Fixes in this release:
--------------------------
- Fixed an issue that caused loss of video when setting the VIDIN_FORMAT for a 
  Multi-Format input to the same format it was already configured to.
- Modified the EDID sent by the Multi-Format input so that it no longer 
  indicates that it supports digital audio.
- Fixed an issue that could result in a VGA input on the multi-format card 
  indicating a valid signal when nothing is connected. 
- Fixed an issue that caused compressed audio to be played on a connected 
  DXLink Receiver's analog audio output.
- Fixed an issue that could caused pink-tinted video on DVI displays connected 
  to DXLink receivers when using the DVX-215x DXLink output.
- Improved compatibility of HDMI inputs with certain HDMI sources, including 
  some WolfVision Document Cameras, that send invalid audio infoframes without 
  sending proper audio status bits which prevented the DVX from displaying 
  video from that source.
- Fixed an issue where Tandberg/Cisco codecs fail to display video when 
  connected as a DVI source to a Multi-Format input.
- Improved audio surround sound (HBR) when video switching
- Fixed false temperature sensor readings being reported to RMS
- Fixed color space settings with some PC/laptops with hdmi outputs
- Fixed Multi-Format DVI video input detect issues
- Fixed output blanking issue when switching video using auto or manual 
  settings, occurs with Misubishi monitors
- Fixed persistant red screen after switching to a non-HDCP source following 
  HDCP failure
- Fixed temporary audio mute on HDMI outputs when inputs are switched for 
  other outputs
- Fixed issue where the output would only send a black screen when a DXLink 
  input receives data from an upstream device in freerun.
- Updated equalizer settings to allow for longer HDMI cables
- Fixed an issue that caused IGMP messages to not be forwarded correctly.
- Fixed multichannel PCM audio support problem
- Fixed persistant blue screen issue caused by selecting different analog input 
  format types on the web interface
- Fixed noise on analog audio output while digital audio modes were selected
- Fixed video issue caused by some devices going in and out of standby or 
  sleep modes
- Fixed video issue caused by mac mini devices going in and out of standby or 
  sleep modes
- Fixed HDMI output muting issue caused by switching between two DXLink inputs
  configured for bypass mode
- Fixed issues caused by noisy sources on HDMI input
- When switching to Video none, pass-through audio on hdmi is not played
- Fixed random muted outputs when switching video
- Fixed issue where the blanking logo/color wouldn't get displayed if there 
  was a noisy HDMI source, in sleep mode, on the multi-format input card
- Added mutex protection for interboard communication
- Fixed a pink screen issue after a reboot, with certain input sources when 
  using the DVX-215x DXLink output port
- Fixed spurious grey screens after a soft reboot
- Fixed HDMI input detection issues observed on some Dell PC models
- Fixed issue where the output would get muted if you switched to an HDCP 
  source while the logo was selected
- Fixed slow switching observed on units with a single DXLink output card
- Improved HDMI output processing to prevent video loss requiring power cycle
- Improved input card detection and noise rejection for certain source devices 
  during sleep mode and hot plug events
- Fixed ?OUTPUT-xxx,nn command to accept highest port number
- Fixed HDMI audio pass-through issue that caused suprious muted audio
- Made further improvements to input detection and noise reduction algorithms 
  on the HDMI input card
- Improved analog audio input to HDMI audio output
- Fixed scalar issue that caused some custom logos to appear distorted 
- Improved compatablity with Display Port sources on HDMI inputs
- Fixed issue where brightness and contrast image adjustments were not always 
  persistent
- Reduced the time it takes to display a blanking image after there is a 
  signal loss on the multi-format input card 
- Added a VIDIN_HDMI_EQ command to enable or disable the equalizer on HDMI 
  input ports.  This does not apply to the DXLink or Multi-Format inputs. 
  The recommended value is DISABLE, but in scenarios where longer HDMI cables 
  are used, this feaure can be enabled to help resolve flickering video. 
  The query ?VIDIN_HDMI_EQ is available as well.
    Syntax: SEND_COMMAND <DEV>, "'VIDIN_HDMI_EQ-<option>'"
    Variables: option = ENABLE, DISABLE (default = DISABLE)
    Example: SEND_COMMAND VIDEO_INPUT_1,"'VIDIN_HDMI_EQ-ENABLE'"
             Enables the HDMI Equalizer of video input port (#1 based on D:P:S)
- Fixed the VIDOUT_ON command.  Using the ENABLE option multiple times in 
  a row would cause video dropouts.
- Improved video detection algorithm on HDMI input cards
