Release Notes

DVX-31xxHD-SP (-T) and DVX-21xxHD-SP (-T)
Enova Presentation Switcher with power Amp

FG#: FG1905-15 (DVX3150HD-SP)
FG#: FG1905-16 (DVX3155HD-SP)
FG#: FG1905-11 (DVX2150HD-SP)
FG#: FG1905-12 (DVX2155HD-SP)
FG#: FG1905-17 (DVX3150HD-T)
FG#: FG1905-18 (DVX3155HD-T)
FG#: FG1905-13 (DVX2150HD-T)
FG#: FG1905-14 (DVX2155HD-T)

Current Firmware Version:
NI Device:        v1.31.6   SW2105_NI_X101_Device_v1_31_6.kit

Release Date: 05/30/2012



NOTE: To insure a successful firmware upgrade with this release please refer
      to the file "SW1905_15_DVX_HD_Programming_Instructions.txt".


Features added in this release:
--------------------------
- Added recognition of new board type


Known Issues:
--------------------------
- None

