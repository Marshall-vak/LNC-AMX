Release Notes

FG#: 
  FG1010-500 (DX-RX, DXLink HDMI Receiver Module)

Release Date: 11/4/2014
Current Released Firmware: v1.9.28
SW1010_500_AVB_KIT_DXLINK_RX_v1_9_28.kit

!!IMPORTANT:  READ PROGRAMMING INFORMATION SECTION BELOW 
IN REGARD TO UPGRADING OLDER FIRMWARE VERSIONS!!

----------------------------------------------------------
Table of Contents
----------------------------------------------------------

1. Prerequisites
2. Features added in this release
3. Fixes in this release:
4. Notable Points
5. Programming Information

----------------------------------------------------------
1. Prerequisites
----------------------------------------------------------

- DXLink RX v1.9.10 (or later) must be loaded on the DXLink 
  Receiver to upgrade

- DXLink TX v1.6.7 (or later) must be loaded on the DXLink 
  Transmitters to get the most benefit from this RX version

- Enova DGX enclosures should ideally have the following:
  DGX 8/16/32 (NI Master) v4.2.395 & DGX kit 2.0.0.11
  DGX 8/16/32/32 (NX Master) v1.2.312 & DGX kit 2.0.0.11

- Enova DVX 315X and 215X should ideally have the following:
  Master v4.8.316
  Switcher Firmware v1.6.31 

- NetLinx Studio V3.4 (4.0 if using NX master)

----------------------------------------------------------
2. Features added in this release:
----------------------------------------------------------

- Added additional HDCP renegotations during hot plug event
- Added an "Offline Recovery Mechanism." In a telnet session,
  type "WD ON" to enable or "WD OFF" to disable this feature.
  A reboot is required after enabling or disabling the state 
  for it to take effect. This also monitors conditions when:
  - A DXLink device processor becomes unstable 
  - The DXLink device�s exceeds it's minimum memory threshold


----------------------------------------------------------
3. Fixes in this release: 
----------------------------------------------------------

- Fixed issue where DVX switches from HDCP to non-HDCP inputs 
  cause the sink to randomly display a black screen instead 
  of the no input logo 
- Fixed a memory leak in ICSP that could negatively impact 
  device's network stability

----------------------------------------------------------
4. Notable Points
----------------------------------------------------------

- If a send command "FACTORYAV" or telnet "RESET FACTORY" 
  is sent, a reboot of the RX will be required.

- PLEASE READ the documentation in regard to the DIP 
  switches located on the bottom of the Tx/Rx modules 
  before attempting to connect to the network

- The RX uses a solid ORANGE screen to indicate an HDCP 
  authentication failure with the connected device 

- If using a hostname in the USB_HID_ROUTE command, the 
  hostname length is limited to 50 characters

----------------------------------------------------------
5. Programming Information
----------------------------------------------------------

!!Important - Two downloads of this kit file may be required 
if upgrading from a version earlier than 1.5.12. A reboot 
of the Rx is needed in between kits. Please follow the following
steps to complete this upgrade on the DXLink RX device!!

  1. Transfer v1.9.28 kit file to the RX. Note: If upgrading 
     from a version earlier than 1.5.12, the upgrade will abort 
     due to memory error. If so, complete steps 2 & 3.
  2. Reboot the RX device so v1.9.28 application can run.
  3. Transfer v1.9.28 kit file again so it can complete the 
     firmware transfer of the other components.

- PLEASE reference Appendix A (Upgrading the Firmware) in the 
  DXLink Instruction Manual for more information.
